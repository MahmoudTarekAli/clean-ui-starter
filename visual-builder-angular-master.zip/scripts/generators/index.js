module.exports = {
  GENERATE_ROUTES: require('./routes'),
  GENERATE_MENU: require('./menu'),
  GENERATE_SETTINGS: require('./settings'),
  GENERATE_PAGES: require('./pages'),
}
