### VB-CLI ###
* Run vb-cli by `yarn vb`
* Select full preview version, this will generate all pages from demo preview

### Load custom config via command line ###
From project root run `node ./scripts/generate.js --config=path-to-config-file.json`