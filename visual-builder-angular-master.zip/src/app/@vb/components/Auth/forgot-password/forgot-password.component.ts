import { Component } from '@angular/core'

@Component({
  selector: 'vb-system-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['../style.component.scss'],
})
export class ForgotPasswordComponent {}
