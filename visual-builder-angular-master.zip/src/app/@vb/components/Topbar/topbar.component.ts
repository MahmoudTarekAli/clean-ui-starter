import { Component } from '@angular/core'

@Component({
  selector: 'vb-topbar',
  templateUrl: './topbar.component.html',
  styleUrls: ['./topbar.component.scss'],
})
export class TopbarComponent {}
