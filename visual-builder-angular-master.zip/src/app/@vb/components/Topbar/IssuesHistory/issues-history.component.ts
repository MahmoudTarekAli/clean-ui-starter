import { Component } from '@angular/core'

@Component({
  selector: 'vb-topbar-issues-history',
  templateUrl: './issues-history.component.html',
  styleUrls: ['./issues-history.component.scss'],
})
export class TopbarIssuesHistoryComponent {}
