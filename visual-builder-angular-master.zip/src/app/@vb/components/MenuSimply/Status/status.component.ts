import { Component } from '@angular/core'

@Component({
  selector: 'vb-menu-simply-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.scss'],
})
export class MenuSimplyStatusComponent {}
