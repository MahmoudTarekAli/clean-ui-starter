import { Component } from '@angular/core'

@Component({
  selector: 'vb-system-404',
  templateUrl: './404.component.html',
})
export class Error404Component {}
