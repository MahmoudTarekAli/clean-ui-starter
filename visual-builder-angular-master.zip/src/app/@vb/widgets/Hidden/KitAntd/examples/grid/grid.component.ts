import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-grid-example',
  templateUrl: './grid.component.html',
})
export class KitAntdGridExampleComponent {}
