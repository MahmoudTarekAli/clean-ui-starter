import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-switch-example',
  templateUrl: './switch.component.html',
})
export class KitAntdSwitchExampleComponent {
  switchValue = false
}
