import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-rate-example',
  templateUrl: './rate.component.html',
})
export class KitAntdRateExampleComponent {}
