import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-divider-example',
  templateUrl: './divider.component.html',
})
export class KitAntdDividerExampleComponent {}
