import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-affix-example',
  templateUrl: './affix.component.html',
})
export class KitAntdAffixExampleComponent {}
