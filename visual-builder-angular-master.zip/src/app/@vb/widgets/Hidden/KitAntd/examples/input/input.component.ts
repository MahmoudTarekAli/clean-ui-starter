import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-input-example',
  templateUrl: './input.component.html',
})
export class KitAntdInputExampleComponent {
  value: string
}
