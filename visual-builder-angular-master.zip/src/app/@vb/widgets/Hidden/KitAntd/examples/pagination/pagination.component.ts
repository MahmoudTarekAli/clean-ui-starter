import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-pagination-example',
  templateUrl: './pagination.component.html',
})
export class KitAntdPaginationExampleComponent {
  current = 1
}
