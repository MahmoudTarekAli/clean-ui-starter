import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-steps-example',
  templateUrl: './steps.component.html',
})
export class KitAntdStepsExampleComponent {}
