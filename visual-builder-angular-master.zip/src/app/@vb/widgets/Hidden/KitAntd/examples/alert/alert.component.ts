import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-alert-example',
  templateUrl: './alert.component.html',
})
export class KitAntdAlertExampleComponent {}
