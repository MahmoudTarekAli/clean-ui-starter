import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-progress-example',
  templateUrl: './progress.component.html',
})
export class KitAntdProgressExampleComponent {}
