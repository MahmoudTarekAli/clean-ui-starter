import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-inputnumber-example',
  templateUrl: './inputnumber.component.html',
})
export class KitAntdInputNumberExampleComponent {
  demoValue = 3
}
