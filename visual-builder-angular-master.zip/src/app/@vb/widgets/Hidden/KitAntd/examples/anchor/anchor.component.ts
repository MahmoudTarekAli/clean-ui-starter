import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-anchor-example',
  templateUrl: './anchor.component.html',
})
export class KitAntdAnchorExampleComponent {}
