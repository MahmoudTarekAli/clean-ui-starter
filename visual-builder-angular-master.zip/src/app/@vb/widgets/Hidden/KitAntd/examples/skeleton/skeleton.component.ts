import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-skeleton-example',
  templateUrl: './skeleton.component.html',
})
export class KitAntdSkeletonExampleComponent {}
