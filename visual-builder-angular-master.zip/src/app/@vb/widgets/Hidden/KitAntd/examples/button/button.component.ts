import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-button-example',
  templateUrl: './button.component.html',
})
export class KitAntdButtonExampleComponent {
  size = 'large'
}
