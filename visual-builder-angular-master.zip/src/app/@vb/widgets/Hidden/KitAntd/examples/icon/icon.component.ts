import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-icon-example',
  templateUrl: './icon.component.html',
})
export class KitAntdIconExampleComponent {}
