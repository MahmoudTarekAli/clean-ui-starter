import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-avatar-example',
  templateUrl: './avatar.component.html',
})
export class KitAntdAvatarExampleComponent {}
