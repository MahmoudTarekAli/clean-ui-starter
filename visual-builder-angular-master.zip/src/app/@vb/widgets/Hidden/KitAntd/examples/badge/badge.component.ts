import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-badge-example',
  templateUrl: './badge.component.html',
})
export class KitAntdBadgeExampleComponent {}
