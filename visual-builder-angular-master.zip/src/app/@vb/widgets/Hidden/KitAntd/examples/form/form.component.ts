import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-form-example',
  templateUrl: './form.component.html',
})
export class KitAntdFormExampleComponent {}
