import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-menu-example',
  templateUrl: './menu.component.html',
})
export class KitAntdMenuExampleComponent {}
