import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-card-example',
  templateUrl: './card.component.html',
})
export class KitAntdCardExampleComponent {}
