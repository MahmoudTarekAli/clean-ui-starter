import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-spin-example',
  templateUrl: './spin.component.html',
})
export class KitAntdSpinExampleComponent {}
