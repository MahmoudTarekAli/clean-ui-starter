import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-radio-example',
  templateUrl: './radio.component.html',
})
export class KitAntdRadioExampleComponent {
  radioValue = 'A'
}
