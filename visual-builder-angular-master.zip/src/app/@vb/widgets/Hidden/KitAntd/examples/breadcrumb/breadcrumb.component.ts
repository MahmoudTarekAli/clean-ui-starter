import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-breadcrumb-example',
  templateUrl: './breadcrumb.component.html',
})
export class KitAntdBreadcrumbExampleComponent {}
