import { Component } from '@angular/core'

@Component({
  selector: 'kit-antd-popover-example',
  templateUrl: './popover.component.html',
})
export class KitAntdPopoverExampleComponent {}
