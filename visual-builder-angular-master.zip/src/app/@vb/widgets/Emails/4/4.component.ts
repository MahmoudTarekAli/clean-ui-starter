import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'vb-emails-4',
  templateUrl: './4.component.html',
  styleUrls: ['./4.component.scss'],
})
export class VbEmails4Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
