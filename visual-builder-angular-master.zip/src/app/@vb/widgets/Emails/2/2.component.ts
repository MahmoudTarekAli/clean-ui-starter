import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'vb-emails-2',
  templateUrl: './2.component.html',
  styleUrls: ['./2.component.scss'],
})
export class VbEmails2Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
