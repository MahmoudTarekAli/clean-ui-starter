import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'vb-emails-1',
  templateUrl: './1.component.html',
  styleUrls: ['./1.component.scss'],
})
export class VbEmails1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
