import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'vb-app-partials-github-write',
  templateUrl: './github-write.component.html',
  styleUrls: ['./github-write.component.scss'],
})
export class VbAppPartialsGithubWriteComponent implements OnInit {
  constructor() {}
  ngOnInit() {}
}
