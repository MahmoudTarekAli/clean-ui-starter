import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'vb-app-partials-do-image',
  templateUrl: './do-image.component.html',
  styleUrls: ['./do-image.component.scss'],
})
export class VbAppPartialsDoImageComponent implements OnInit {
  constructor() {}
  ngOnInit() {}
}
