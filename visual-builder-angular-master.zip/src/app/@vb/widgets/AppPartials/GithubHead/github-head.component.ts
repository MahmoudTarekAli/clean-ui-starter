import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'vb-app-partials-github-head',
  templateUrl: './github-head.component.html',
  styleUrls: ['./github-head.component.scss'],
})
export class VbAppPartialsGithubHeadComponent implements OnInit {
  constructor() {}
  ngOnInit() {}
}
