import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'vb-forms-3',
  templateUrl: './3.component.html',
  styleUrls: ['./3.component.scss'],
})
export class VbForms3Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
