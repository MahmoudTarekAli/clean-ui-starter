import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'vb-forms-6',
  templateUrl: './6.component.html',
  styleUrls: ['./6.component.scss'],
})
export class VbForms6Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
